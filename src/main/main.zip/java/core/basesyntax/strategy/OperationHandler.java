package core.basesyntax.strategy;

public interface OperationHandler {
    int handle(int balance, int count);
}
