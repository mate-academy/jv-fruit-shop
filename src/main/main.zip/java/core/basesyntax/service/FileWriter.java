package core.basesyntax.service;

public interface FileWriter {
    void writeToFile(String report, String pathToFile);
}
