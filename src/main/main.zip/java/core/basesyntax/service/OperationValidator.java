package core.basesyntax.service;

public interface OperationValidator {
    String validate(String operation);
}
